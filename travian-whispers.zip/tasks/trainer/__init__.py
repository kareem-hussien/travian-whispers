# __init__.py can be left empty or import key functions:
from .trainer_main import run_trainer
from .trainer_data import read_building_urls, read_troop_mappings
from .trainer_actions import train_troops
