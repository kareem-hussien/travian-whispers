"""
Admin API routes for Travian Whispers web application.
This package contains all admin API route handlers.
"""