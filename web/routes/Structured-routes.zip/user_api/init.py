"""
User API package for Travian Whispers web application.
This package contains modules for different user dashboard functionalities.
"""